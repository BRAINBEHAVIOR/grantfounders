# Prompt Mestre: Decision Intelligence Operating System (DIOS) GrantFounders

**Instrução para Manus:**

Você deve atuar como um engenheiro de software sênior e estrategista de produto. Sua tarefa é construir a **infraestrutura de produção** para o **Decision Intelligence Operating System (DIOS)** da GrantFounders, que opera como um serviço de **Decision-as-a-Service (DaaS)**.

**Visão do Produto:**

O GrantFounders não é uma plataforma de *grants*, mas sim um **Decision Intelligence Operating System for Capital Allocation**. Ele é o **Bloomberg + Palantir do dinheiro federal**, focado em prever o comportamento do financiamento público e institucional.

**Núcleo Cognitivo (Abasensor™):**

O núcleo do sistema é o **Abasensor™**, que não responde dados, mas sim **Decisões**. O sistema deve ser construído para suportar as seguintes funções de DaaS:

1.  **Matching Preditivo:** Conexão de projetos com oportunidades de financiamento (FOAs).
2.  **Scoring:** Cálculo do **Funding Readiness Score (FRS)** com base no **DNA de Financiamento** da agência-alvo.
3.  **Forecast de Capital:** Previsão de onde o dinheiro será alocado.
4.  **Compliance Firewall:** Verificação automática de regras de conformidade (ex: SBIR, RLS).
5.  **Autopilot Plans:** Geração de planos de ação estratégicos para o cliente.

**Requisitos de Infraestrutura e Segurança:**

1.  **Backend (Decision Engine):**
    *   **Tecnologia:** Python/Flask (ou FastAPI, se preferir).
    *   **Banco de Dados:** PostgreSQL/Supabase.
    *   **Segurança Crítica:** Implementação obrigatória de **Row Level Security (RLS)** multi-tenant, garantindo o isolamento de dados por `org_id` (Federal-Grade Data Isolation). O cliente só pode acessar seus próprios dados e o modelo de IA não pode ser treinado com dados de outros clientes.
    *   **Conexão:** O backend deve ser configurado para se conectar a um banco de dados PostgreSQL externo (Supabase) via variável de ambiente `DATABASE_URL`.

2.  **Frontend (Decision Dashboard):**
    *   **Tecnologia:** React/Vite.
    *   **Função:** Servir como a interface de usuário para o **Decision-as-a-Service**, permitindo a ingestão de projetos e a visualização do **Relatório de Análise Preditiva (RAP)**.
    *   **Branding:** Manter o branding premium: Paleta Navy/Gold, e a marca **"Powered by Abasensor™"** em destaque.

3.  **Monetização (Decision-as-a-Service):**
    *   O sistema deve ser estruturado para suportar o modelo de contrato de alto valor: Developer ($99/mês), Pro ($499/mês), Institutional ($2k-$10k/mês) e Government ($50k-$500k/ano).
    *   O acesso deve ser via **API Key** (o cliente consulta o cérebro, não o leva).

**Ação Requerida:**

1.  **Criar o repositório de código** para o backend (Decision Engine) e o frontend (Decision Dashboard).
2.  **Implementar o código-fonte** do backend (Flask/Python) e do frontend (React) conforme o documento de compilação anexo (se disponível, ou recriar a estrutura lógica).
3.  **Fornecer o passo a passo exato** para o deploy em um ambiente de produção (ex: Vercel/Netlify para frontend, AWS/Google Cloud Run para backend).
4.  **Garantir que o código seja modular** para facilitar a integração com o Supabase RLS e a expansão futura dos módulos de DaaS (Compliance Firewall, Autopilot).

**Entrega:**

Um documento técnico (Markdown ou PDF) contendo o código-fonte completo e o roadmap de deploy para a infraestrutura de produção do **Decision Intelligence Operating System (DIOS)**.

**Visão Final:**

Construir uma **Infraestrutura Estratégica** que se torna a **camada obrigatória** para a alocação de capital institucional. O foco é em **Decisão**, não em dados.
